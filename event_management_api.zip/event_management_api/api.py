from flask import *
from database import*
import uuid
api=Blueprint('api',__name__)

@api.route('/login',methods=['GET','POST'])
def login():
    username1=request.form['username1']
    password=request.form['password']
    s="select * from login where Username='%s' and Password='%s'"%(username1,password)
    res=select(s)
    if res:
        return jsonify({'status':'true','type':res[0]['Usertype'],'lid':res[0]['Login_id']})
    else:
        return jsonify({'status':'failed'})

@api.route('/reg_user',methods=['GET','POST'])
def reg_user():
    fname=request.form['fname']
    lname=request.form['lname']
    place=request.form['place']
    phone=request.form['phone']
    email=request.form['email']
    uname=request.form['uname']
    pword=request.form['pword']
    a="insert into login values(null,'%s','%s','user')"%(uname,pword)
    lid=insert(a)
    
    s="insert into user values(null,'%s','%s','%s','%s','%s','%s')"%(lid,fname,lname,place,phone,email)
    res=insert(s)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'failed'})

@api.route('/reg_event',methods=['GET','POST'])
def reg_event():
    fname=request.form['fname']
    lname=request.form['lname']
    place=request.form['place']
    phone=request.form['phone']
    email=request.form['email']
    uname=request.form['uname']
    pword=request.form['pword']
    a="insert into login values(null,'%s','%s','pending')"%(uname,pword)
    lid=insert(a)
    
    s="insert into eventteam values(null,'%s','%s','%s','%s','%s','%s')"%(lid,fname,lname,place,phone,email)
    res=insert(s)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'failed'})

@api.route('/view_event',methods=['GET','POST'])
def view_event():
    s="SELECT *,CONCAT(`Firstname`,' ',`Lastname`) AS fname FROM `eventteam` inner join login using(Login_id)"
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'failed'})
@api.route('/accept_event',methods=['get','post'])
def accept_event():
    dbid=request.form['dbid']
    a="update login set Usertype='event' where Login_id='%s'"%(dbid)
    res=update(a)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'failed'})

@api.route('/areject_event',methods=['get','post'])
def areject_event():
    dbid=request.form['dbid']
    a="update login set Usertype='reject' where Login_id='%s'"%(dbid)
    res=update(a)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'failed'})

@api.route('/view_user',methods=['GET','POST'])
def view_user():
    s="SELECT *,CONCAT(`Firstname`,' ',`Lastname`) AS fname FROM `user`"
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'failed'})
    
@api.route('/view_booking_decoration',methods=['GET','POST'])
def view_booking_decoration():
    s="SELECT *,CONCAT(`Firstname`,`Lastname`) AS Fname FROM `decorationbooking` INNER JOIN `user` USING(`User_id`)"
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'failed'})


@api.route('/view_booking_food',methods=['GET','POST'])
def view_booking_food():
    s="SELECT *,CONCAT(`Firstname`,`Lastname`) AS Fname FROM `foodbooking` INNER JOIN `user` USING(`User_id`) inner join `foodbookingchild` using(`Fbooking_id`) inner join `food` using(`Food_id`)"
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'failed'})
    
@api.route('/aview_complaint',methods=['get','post'])
def aview_complaint():
   
    s="select * from `Complaint` inner join `user` on(`Complaint`.`User_id`=`user`.`User_id`) "
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='failed')
@api.route('/send_replay',methods=['get','post'])
def send_replay():
    complaint_id=request.form['complaint_id']
    replay=request.form['replay']

    s="update `Complaint` set Reply='%s' where Complaint_id='%s' "%(replay,complaint_id)
    res=update(s)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'failed'})
    
@api.route('/add_decoration',methods=['GET','POST'])
def add_decoration():
    decoration=request.form['decoration']
    amount=request.form['amount']
    details=request.form['details']
    lid=request.form['lid']
    image=request.files['image']
    path="static/images/"+str(uuid.uuid4())+image.filename
    image.save(path)
    s="insert into decoration values(null,(SELECT `Eventteam_id` FROM `eventteam` WHERE `Login_id`='%s'),'%s','%s','%s','%s')"%(lid,decoration,amount,details,path)
    res=insert(s)
    if res:
      if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'failed'})  
    
@api.route('/view_decoration',methods=['get','post'])
def view_decoration():
    lid=request.form['lid']
    s="SELECT * FROM `decoration` INNER JOIN `eventteam` ON(`decoration`.`Team_id`=`eventteam`.`Eventteam_id`) WHERE `eventteam`.`Login_id`='%s'"%(lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='failed')
    
@api.route('/delete_decoration',methods=['GET','POST'])
def delete_decoration():
    id=request.form['id']
    s="delete from decoration where Decoration_id='%s'"%(id)
    res=delete(s)
    if res:
        return jsonify(status='true')
    else:
        return jsonify(status='failed')
    
@api.route('/add_food',methods=['GET','POST'])
def add_food():
    fname=request.form['fname']
    amt=request.form['amt']
    det=request.form['det']
    lid=request.form['lid']
    
    s="INSERT INTO `food` VALUES(NULL,(SELECT `Eventteam_id` FROM `eventteam` WHERE `Login_id`='%s'),'%s','%s','%s')"%(lid,fname,amt,det)
    res=insert(s)
    if res:
      if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'failed'})  
    
@api.route('/view_food',methods=['get','post'])
def view_food():
    lid=request.form['lid']
    s="SELECT * FROM `food` INNER JOIN `eventteam` ON(`food`.`Team_id`=`eventteam`.`Eventteam_id`) WHERE `eventteam`.`Login_id`='%s'"%(lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='failed')
    
@api.route('/delete_food',methods=['GET','POST'])
def delete_food():
    id=request.form['id']
    s="DELETE FROM `food` WHERE `Food_id`='%s'"%(id)
    res=delete(s)
    if res:
        return jsonify(status='true')
    else:
        return jsonify(status='failed')
    
@api.route('/eview_decoration',methods=['get','post'])
def eview_decoration():
    lid=request.form['lid']
    s="SELECT * FROM `decoration` INNER JOIN `eventteam` ON(`decoration`.`Team_id`=`eventteam`.`Eventteam_id`) WHERE `eventteam`.`Login_id`='%s'"%(lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='failed')  

@api.route('/view_decoration_booking',methods=['get','post'])
def view_decoration_booking():
    lid=request.form['lid']
    s="SELECT *,CONCAT(`Firstname`,`Lastname`) AS Fname FROM `decorationbooking` INNER JOIN `decoration` using(`Decoration_id`) INNER JOIN `user` using (`User_id`) WHERE `Team_id`=(SELECT `Eventteam_id` FROM `eventteam` where `Login_id`='%s')"%(lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='failed')  
    
@api.route('/accept_dbooking',methods=['get','post'])
def accept_dbooking():
    
    dbid=request.form['dbid']
    s="UPDATE `decorationbooking` SET `Status`='accept' WHERE `Dbooking_id`='%s'"%(dbid)
    res=update(s)
    if res:
        return jsonify(status='true')
    else:
        return jsonify(status='failed')
@api.route('/dreject_booking',methods=['get','post'])
def dreject_booking():
    
    dbid=request.form['dbid']
    s="UPDATE `decorationbooking` SET `Status`='reject' WHERE `Dbooking_id`='%s'"%(dbid)
    res=update(s)
    if res:
        return jsonify(status='true')
    else:
        return jsonify(status='failed')

@api.route('/view_food_booking',methods=['get','post'])
def view_food_booking():
    lid=request.form['lid']
    s="SELECT *,CONCAT(`user`.`Firstname`,`user`.`Lastname`)AS Fname FROM `foodbooking` INNER JOIN `foodbookingchild` ON(`foodbooking`.`Fbooking_id`=`foodbookingchild`.`Fbooking_id`) INNER JOIN `food` ON(`foodbookingchild`.`Food_id`=`food`.`Food_id`) INNER JOIN `user` ON(`foodbooking`.`User_id`=`user`.`User_id`) WHERE `Team_id`=(SELECT `Eventteam_id` FROM `eventteam` WHERE `Login_id`='%s')"%(lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='failed') 
    
@api.route('/accept_fbooking',methods=['GET','POST'])
def accept_fbooking():
    dbid=request.form['dbid']
    s="UPDATE `foodbooking` SET `Status`='accept' WHERE `Fbooking_id`='%s'"%(dbid)
    res=update(s)
    if res:
        return jsonify(status='true')
    else:
        return jsonify(status='failed')
@api.route('/freject_booking',methods=['GET','POST'])
def freject_booking():
    dbid=request.form['dbid']
    s="UPDATE `foodbooking` SET `Status`='reject' WHERE `Fbooking_id`='%s'"%(dbid)
    res=update(s)
    if res:
        return jsonify(status='true')
    else:
        return jsonify(status='failed')
    
@api.route('/picked_food',methods=['GET','POST'])
def picked_food():
    dbid=request.form['dbid']
    s="UPDATE `foodbooking` SET `Status`='picked' WHERE `Fbooking_id`='%s'"%(dbid)
    update(s)
    r="insert into pickedupfoods values(null,(select Foodbookingchild_id from foodbookingchild where Fbooking_id='%s'),'picked')"%(dbid)
    res=insert(r)
    if res:
        return jsonify(status='true')
    else:
        return jsonify(status='failed')
    
@api.route('/user_view_event',methods=['GET','POST'])
def user_view_event():
    s="select *,concat(`Firstname`,`Lastname`)as Fname from decoration inner join `eventteam` on(`decoration`.`Team_id`=`eventteam`.`Eventteam_id`)"
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='failed') 

@api.route('/user_view_food',methods=['GET','POST'])
def user_view_food():
    s="select *,concat(`Firstname`,`Lastname`)as Fname from `food` inner join `eventteam` on(`food`.`Team_id`=`eventteam`.`Eventteam_id`)"
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='failed') 
    
@api.route('/user_view_decoration',methods=['GET','POST'])
def user_view_decoration():
    did=request.form['did']
    s="select * from decoration where Decoration_id='%s'"%(did)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        
        return jsonify(status='failed') 
    
@api.route('/user_add_decoration',methods=['get','post'])
def user_add_decoration():
    lid=request.form['lid']
    decoid=request.form['did']
    amount=request.form['amt']
    quantity=request.form['quantity']
    total=request.form['total']
    place=request.form['place']
    date=request.form['date']
    s="INSERT INTO `decorationbooking` VALUES(NULL,'%s',(select User_id from user where Login_id='%s'),'%s','%s','%s','%s','pending')"%(decoid,lid,quantity,total,place,date)
    res=insert(s)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'false'})
    
@api.route('/user_add_cartfood',methods=['get','post'])
def user_add_cartfood():
    lid=request.form['lid']
    decoid=request.form['did']
    amount=request.form['amt']
    quantity=request.form['quantity']
    total=request.form['total']
    place=request.form['place']
    date=request.form['date']
    s="INSERT INTO `foodbooking` VALUES(NULL,(select `Team_id` from `food` where `Food_id`='%s'),(select User_id from user where Login_id='%s'),'%s','%s','pending')"%(decoid,lid,total,date)
    res1=insert(s)
    c="INSERT INTO `foodbookingchild` VALUES(NULL,'%s','%s','%s')"%(res1,decoid,amount)
    res=insert(c)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'false'})
    
@api.route('/user_view_decorationbooking',methods=['get','post'])
def user_view_decorationbooking():
    lid=request.form['lid']
    s="SELECT * FROM `decorationbooking` INNER JOIN `decoration` USING(`Decoration_id`) WHERE `User_id`=(SELECT `User_id` FROM `user` WHERE `Login_id`='%s')"%(lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='false')
    
@api.route('/user_view_foodbooking',methods=['get','post'])
def user_view_foodbooking():
    lid=request.form['lid']
    s="select * from `foodbooking` inner join `foodbookingchild` using(`Fbooking_id`) inner join `food` using(`Food_id`) where `User_id`=(select `User_id` from `user` where `Login_id`='%s')"%(lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify(status='false')
    
@api.route('/user_deco_payment',methods=['get','post'])
def user_deco_payment():
    did=request.form['did']
    amt=request.form['amt']
    s = float(amt) * 0.1 
    amount=float(amt)-s
    i="insert into payment values(null,'%s','%s','%s',curdate(),'paid')"%(did,s,amount)
    res=insert(i)
    s="UPDATE decorationbooking SET `Status`='paid' WHERE `Decoration_id`='%s'"%(did)
    res=update(did)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'false'})
    
@api.route('/user_food_payment',methods=['get','post'])
def user_food_payment():
    did=request.form['did']
    amt=request.form['amt']
    s = float(amt) * 0.1 
    amount=float(amt)-s
    i="insert into payment values(null,'%s','%s','%s','curdate()','paid')"%(did,s,amount)
    res=insert(i)
    s="update foodbooking set Status='paid' where Fbooking_id='%s'"%(did)
    update(s)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'false'})
    
@api.route('/add_complaint',methods=['GET','POST'])
def add_complaint():
    message=request.form['categoryname']
    lid=request.form['lid']
    s="insert into complaint values(null,'%s','%s','pending',curdate())"%(lid,message)
    res=insert(s)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'false'})

@api.route('/view_complaint',methods=['GET','POST'])
def view_complaint():
    
    lid=request.form['lid']
    s="select * from complaint where User_id='%s'"%(lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'false'})
    
@api.route('/view_chat',methods=['GET','POST'])
def view_chat():
    lid=request.form['lid']
    sid=request.form['rid']    
    s="select * from message where Sender_id='%s' and Receiver_id=(select `Login_id` from `eventteam` where `Eventteam_id`='%s') or Sender_id=(select `Login_id` from `eventteam` where `Eventteam_id`='%s') and Receiver_id='%s'"%(lid,sid,sid,lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'false'})
    
@api.route('/send_message',methods=['GET','POST'])
def send_message():
    lid=request.form['lid']
    rid=request.form['rid']
    message=request.form['message']
  
    s="insert into message values(null,'%s',(select `Login_id` from `eventteam` where `Eventteam_id`='%s'),'%s',curdate())"%(lid,rid,message)
    res=insert(s)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'false'})
    
@api.route('/eview_chat',methods=['GET','POST'])
def eview_chat():
    lid=request.form['lid']
    sid=request.form['rid']    
    s="select * from message where Sender_id='%s' and Receiver_id=(select `Login_id` from `user` where `User_id`='%s') or Sender_id=(select `Login_id` from `user` where `User_id`='%s') and Receiver_id='%s'"%(lid,sid,sid,lid)
    res=select(s)
    if res:
        return jsonify(status='true',data=res)
    else:
        return jsonify({'status':'false'})
    
@api.route('/esend_message',methods=['GET','POST'])
def esend_message():
    lid=request.form['lid']
    rid=request.form['rid']
    message=request.form['message']
  
    s="insert into message values(null,'%s',(select `Login_id` from `user` where `User_id`='%s'),'%s',curdate())"%(lid,rid,message)
    res=insert(s)
    if res:
        return jsonify({'status':'true'})
    else:
        return jsonify({'status':'false'})