/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.7.9 : Database - event_management_flutter
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`event_management_flutter` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `event_management_flutter`;

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `Complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `User_id` int(11) DEFAULT NULL,
  `Complaint` varchar(50) DEFAULT NULL,
  `Reply` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Complaint_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `complaint` */

insert  into `complaint`(`Complaint_id`,`User_id`,`Complaint`,`Reply`,`Date`) values 
(1,3,'hsind','hekkd','2024-12-19');
insert  into `complaint`(`Complaint_id`,`User_id`,`Complaint`,`Reply`,`Date`) values 
(2,3,'hsind','ghj','2024-12-19');
insert  into `complaint`(`Complaint_id`,`User_id`,`Complaint`,`Reply`,`Date`) values 
(3,3,'hsind','ok','2024-12-19');
insert  into `complaint`(`Complaint_id`,`User_id`,`Complaint`,`Reply`,`Date`) values 
(4,3,'hsind','good','2024-12-19');
insert  into `complaint`(`Complaint_id`,`User_id`,`Complaint`,`Reply`,`Date`) values 
(5,12,'good experience','pending','2025-01-07');

/*Table structure for table `decoration` */

DROP TABLE IF EXISTS `decoration`;

CREATE TABLE `decoration` (
  `Decoration_id` int(11) NOT NULL AUTO_INCREMENT,
  `Team_id` int(11) DEFAULT NULL,
  `Decoration` varchar(50) DEFAULT NULL,
  `Amount` varchar(50) DEFAULT NULL,
  `Details` varchar(50) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`Decoration_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `decoration` */

insert  into `decoration`(`Decoration_id`,`Team_id`,`Decoration`,`Amount`,`Details`,`image_url`) values 
(1,3,'wedding ','1500','per sqft including flowers ','static/images/b0b5a1f5-da94-4e64-ac39-59202f8b09821000035837.jpg');
insert  into `decoration`(`Decoration_id`,`Team_id`,`Decoration`,`Amount`,`Details`,`image_url`) values 
(2,6,'tghwb','100','rfg','static/images/d2b1afd0-e103-4db5-a46e-4094102925091000152004.jpg');

/*Table structure for table `decorationbooking` */

DROP TABLE IF EXISTS `decorationbooking`;

CREATE TABLE `decorationbooking` (
  `Dbooking_id` int(11) NOT NULL AUTO_INCREMENT,
  `Decoration_id` int(11) DEFAULT NULL,
  `User_id` int(11) DEFAULT NULL,
  `Hall` varchar(50) DEFAULT NULL,
  `Amount` varchar(50) DEFAULT NULL,
  `Place` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Dbooking_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `decorationbooking` */

insert  into `decorationbooking`(`Dbooking_id`,`Decoration_id`,`User_id`,`Hall`,`Amount`,`Place`,`Date`,`Status`) values 
(1,1,3,'1','1500.00','hsuygg','2024-12-20T00:00:00.000','paid');
insert  into `decorationbooking`(`Dbooking_id`,`Decoration_id`,`User_id`,`Hall`,`Amount`,`Place`,`Date`,`Status`) values 
(2,1,3,'9','13500.00','fagvs','2024-12-28T00:00:00.000','accept');
insert  into `decorationbooking`(`Dbooking_id`,`Decoration_id`,`User_id`,`Hall`,`Amount`,`Place`,`Date`,`Status`) values 
(3,2,6,'1','100.00','','2025-01-08T00:00:00.000','pending');

/*Table structure for table `eventteam` */

DROP TABLE IF EXISTS `eventteam`;

CREATE TABLE `eventteam` (
  `Eventteam_id` int(11) NOT NULL AUTO_INCREMENT,
  `Login_id` int(11) DEFAULT NULL,
  `Firstname` varchar(50) DEFAULT NULL,
  `Lastname` varchar(50) DEFAULT NULL,
  `Place` varchar(50) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Eventteam_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `eventteam` */

insert  into `eventteam`(`Eventteam_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(1,5,'vbn','nn','bnbbh','699','ccc@ffb.nkm');
insert  into `eventteam`(`Eventteam_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(2,8,'crazy','gdhn','angamk','65698','ffsbb@gamaol.com');
insert  into `eventteam`(`Eventteam_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(3,7,'crazy','gdhn','angamk','65698','ffsbb@gamaol.com');
insert  into `eventteam`(`Eventteam_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(4,9,'crazy','gdhn','angamk','65698','ffsbb@gamaol.com');
insert  into `eventteam`(`Eventteam_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(5,11,'dgh','fghj','fgh','266565','hj@dm.hxkm');
insert  into `eventteam`(`Eventteam_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(6,14,'fole','tue','tuja','5313889078','thh@fsuj.com');

/*Table structure for table `food` */

DROP TABLE IF EXISTS `food`;

CREATE TABLE `food` (
  `Food_id` int(11) NOT NULL AUTO_INCREMENT,
  `Team_id` int(11) DEFAULT NULL,
  `Food` varchar(50) DEFAULT NULL,
  `Amount` varchar(50) DEFAULT NULL,
  `Details` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`Food_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `food` */

insert  into `food`(`Food_id`,`Team_id`,`Food`,`Amount`,`Details`) values 
(1,3,'bhiriyani','150','1 plate chicken biryani 150 including drinks ');
insert  into `food`(`Food_id`,`Team_id`,`Food`,`Amount`,`Details`) values 
(2,3,'dudfhf','fjf','xdb');
insert  into `food`(`Food_id`,`Team_id`,`Food`,`Amount`,`Details`) values 
(3,6,'maggie','290','gdukdn');

/*Table structure for table `foodbooking` */

DROP TABLE IF EXISTS `foodbooking`;

CREATE TABLE `foodbooking` (
  `Fbooking_id` int(11) NOT NULL AUTO_INCREMENT,
  `Eventteam_id` int(11) DEFAULT NULL,
  `User_id` int(11) DEFAULT NULL,
  `Total` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Fbooking_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `foodbooking` */

insert  into `foodbooking`(`Fbooking_id`,`Eventteam_id`,`User_id`,`Total`,`Date`,`Status`) values 
(1,3,3,'150.00','2024-12-27T00:00:00.000','accept');
insert  into `foodbooking`(`Fbooking_id`,`Eventteam_id`,`User_id`,`Total`,`Date`,`Status`) values 
(2,3,3,'150.00','2024-12-28','pending');
insert  into `foodbooking`(`Fbooking_id`,`Eventteam_id`,`User_id`,`Total`,`Date`,`Status`) values 
(3,3,6,'7500.00','2024-12-28','picked');

/*Table structure for table `foodbookingchild` */

DROP TABLE IF EXISTS `foodbookingchild`;

CREATE TABLE `foodbookingchild` (
  `Foodbookingchild_id` int(11) NOT NULL AUTO_INCREMENT,
  `Fbooking_id` int(11) DEFAULT NULL,
  `Food_id` int(11) DEFAULT NULL,
  `Amount` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Foodbookingchild_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `foodbookingchild` */

insert  into `foodbookingchild`(`Foodbookingchild_id`,`Fbooking_id`,`Food_id`,`Amount`) values 
(1,1,1,'150');
insert  into `foodbookingchild`(`Foodbookingchild_id`,`Fbooking_id`,`Food_id`,`Amount`) values 
(2,2,1,'150');
insert  into `foodbookingchild`(`Foodbookingchild_id`,`Fbooking_id`,`Food_id`,`Amount`) values 
(3,3,1,'150');

/*Table structure for table `image` */

DROP TABLE IF EXISTS `image`;

CREATE TABLE `image` (
  `Image_id` int(11) DEFAULT NULL,
  `Decoration_id` int(11) DEFAULT NULL,
  `File` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `image` */

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `Login_id` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `Usertype` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Login_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(1,'admin','admin','admin');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(2,'b','v','user');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(3,'thh','thh','user');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(4,'hhb','gg','user');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(5,'hhh','trf','event');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(10,'cfg','cfg','user');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(7,'crazy','cccc','event');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(11,'ebve','ebve','event');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(12,'gg','gg','user');
insert  into `login`(`Login_id`,`Username`,`Password`,`Usertype`) values 
(14,'fl','fl','event');

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `Message_id` int(11) NOT NULL AUTO_INCREMENT,
  `Sender_id` int(11) DEFAULT NULL,
  `Receiver_id` int(11) DEFAULT NULL,
  `Message` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `message` */

insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(1,3,7,'hai','curdate()');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(2,3,7,'hai','curdate()');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(3,3,7,'h','2024-12-19');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(4,3,7,'h','2024-12-19');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(5,7,3,'helo','2024-12-19');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(6,3,7,'hai','2024-12-19');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(7,3,7,'Ha','2024-12-19');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(8,3,8,'hai','2024-12-19');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(9,3,7,'hai','2024-12-20');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(10,7,3,'hai','2024-12-20');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(11,7,12,'hai I picked ur order','2025-01-07');
insert  into `message`(`Message_id`,`Sender_id`,`Receiver_id`,`Message`,`Date`) values 
(12,12,7,'thank you','2025-01-07');

/*Table structure for table `payment` */

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `Payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `Booking_id` int(11) DEFAULT NULL,
  `Commission_to_admin` varchar(50) DEFAULT NULL,
  `Amount` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Payment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `payment` */

insert  into `payment`(`Payment_id`,`Booking_id`,`Commission_to_admin`,`Amount`,`Date`,`Status`) values 
(6,3,'750.0','6750.0','curdate()','paid');
insert  into `payment`(`Payment_id`,`Booking_id`,`Commission_to_admin`,`Amount`,`Date`,`Status`) values 
(4,3,'750.0','6750.0','2025-01-07','paid');
insert  into `payment`(`Payment_id`,`Booking_id`,`Commission_to_admin`,`Amount`,`Date`,`Status`) values 
(5,3,'750.0','6750.0','2025-01-07','paid');

/*Table structure for table `pickedupfoods` */

DROP TABLE IF EXISTS `pickedupfoods`;

CREATE TABLE `pickedupfoods` (
  `Pickedupuploads_id` int(11) NOT NULL AUTO_INCREMENT,
  `Foodbookingchild_id` int(11) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Pickedupuploads_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `pickedupfoods` */

insert  into `pickedupfoods`(`Pickedupuploads_id`,`Foodbookingchild_id`,`status`) values 
(1,3,'picked');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `User_id` int(11) NOT NULL AUTO_INCREMENT,
  `Login_id` int(11) DEFAULT NULL,
  `Firstname` varchar(50) DEFAULT NULL,
  `Lastname` varchar(50) DEFAULT NULL,
  `Place` varchar(50) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`User_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`User_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(1,1,'a','a','a','4','amil@gmail.com');
insert  into `user`(`User_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(2,2,'a','a','a','4','amil@gmail.com');
insert  into `user`(`User_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(3,3,'catering','hnn','vvbn','9666','gvb@cat.con');
insert  into `user`(`User_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(4,4,'a','sbbb','bn','566','bhj@nke.com');
insert  into `user`(`User_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(5,10,'hssdf','ccgj','dgfhgn','4656855','cfhjj@m.ckkm');
insert  into `user`(`User_id`,`Login_id`,`Firstname`,`Lastname`,`Place`,`Phone`,`Email`) values 
(6,12,'aaaaa','klsjh','6e8n','56469','fgbsu@dagh.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
